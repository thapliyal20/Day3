
public class Tablet extends Medicine
{
	public Tablet(){
		super();
	}
	public Tablet(String MedName, String CompName, Date d1, float price) {
	super(MedName, CompName, price,  d1);
	}
	public String dispMedicineInfo() {
		return "Tablet\n  "+super.dispMedicineInfo()+"Store at cool and dry place";
	}
	
}

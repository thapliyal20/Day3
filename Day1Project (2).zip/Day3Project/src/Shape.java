
public abstract class Shape 
{
	private int radius;
	public String type;
	
	public int getRadius() {
		return radius;
	}
	public void setRadius(int radius) {
		this.radius = radius;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Shape(){}
	public Shape(int radius,String type)
	{
		this.radius=radius;
		this.type=type;
	}
	public void drawShape()
	{
		System.out.println(type +" Shape Drawn with RED COLOR");
	}
	public abstract float calcArea();
	public abstract float calcVolume();
}

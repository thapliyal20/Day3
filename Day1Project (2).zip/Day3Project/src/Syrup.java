
public class Syrup extends Medicine
{
	public Syrup(){
		super();
	}
public Syrup(String medName, String compName, float price, Date d1) {
		
		super(medName,compName,price,d1);
	}
public String dispMedicineInfo() {
	return "Syrup\n  "+super.dispMedicineInfo()+"Shake well before use";
}
}

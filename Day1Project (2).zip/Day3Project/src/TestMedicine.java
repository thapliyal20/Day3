import java.util.Scanner;


public class TestMedicine
{

	public static void main(String[] args) 
	{
		int numOfMedicine;
		int type;
		String medName,compName;
		int day,mon,year;
		float price;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the number of Medicine: ");
		numOfMedicine=sc.nextInt();
		Medicine medis[]=new Medicine[numOfMedicine];
		Date d1[]=new Date[numOfMedicine];
		for(int i=0;i<numOfMedicine;i++)
		{
			System.out.println("Select type of Medicine :\n1.Tablet \n2.Ointment \n3.Syrup");
			type=sc.nextInt();
			System.out.println("Enter the Medicine Name :\n");
			medName=sc.next();
			System.out.println("Enter the Company Name :\n");
			compName=sc.next();
			System.out.println("Enter the date in dd mm yy format: ");
			day=sc.nextInt();
			mon=sc.nextInt();
			year=sc.nextInt();
			System.out.println("Enter the price of Medicine :\n");
			price=sc.nextFloat();
			d1[i]=new Date(day,mon,year);
			switch(type){
				case 1: medis[i]=new Tablet(medName,compName,d1[i],price);
				break;
				case 2: medis[i]=new Ointment(medName,compName,price,d1[i]);
				break;
				case 3: medis[i]=new Syrup(medName,compName,price,d1[i]);
				break;
				default:System.out.println("Invalid Input");
				break;
			}
		}
		for(int i=0;i<numOfMedicine;i++){
			System.out.println(medis[i].dispMedicineInfo());
		}
	}
}


public class CheckNumber 
{

	public static void main(String[] args) 
	{
		int num1=Integer.parseInt(args[0]);
		if(num1<0){
			System.out.println("The result is negative");
		}
		
		else{
			System.out.println("The result is positive");
		}
	}

}


public class Ointment extends Medicine
{
	public Ointment(){
		super();
	}
public Ointment(String medName, String compName, float price, Date d1) {
		
		super(medName,compName,price,d1);
	}
public String dispMedicineInfo() {
	return "Ointment\n  "+super.dispMedicineInfo()+"For external use Only";
}
}

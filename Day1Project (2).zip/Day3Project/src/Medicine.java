
public class Medicine
{
	private String medName;
	private String compName;
	private float price;
	Date d1= new Date();
	public Medicine() {
		super();
		
	}
	public Medicine(String medName, String compName, float price, Date d1) {
		
		this.medName = medName;
		this.compName = compName;
		this.price = price;
		this.d1 = d1;
	}
	
	public String dispMedicineInfo() {
		return "Medicine [medName=" + medName + ", compName=" + compName
				+ ", price=" + price + ", d1=" + d1.disDate() + "]";
	}
	
	
	
	
	
	
	
	
	
}

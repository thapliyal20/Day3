
public class WageEmp extends Emp
{
	
	public WageEmp(int empId, String empName, float empSal) {
		super(empId, empName, empSal);
		
	}
	int noOfHrs;
	int ratePerHrs;
	public WageEmp()
	{
		super();							//empty constructor is called
	}
	public WageEmp(int empId, String empName, float empSal, int noOfHrs,
				int ratePerHrs)
	{
		super(empId, empName, empSal);      //to call parent class constructor
		this.noOfHrs = noOfHrs;
		this.ratePerHrs = ratePerHrs;
		
	}
	public String dispInfo()
	{
		return super.dispInfo()+" noOfHrs "+noOfHrs+" ratePerHrs" +ratePerHrs;
	}
	public float calcEmpAnnualSal()
	{
		return (super.calcEmpAnnualSal())+(noOfHrs*ratePerHrs*22*12);
	}
}
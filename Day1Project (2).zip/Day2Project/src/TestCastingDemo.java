
public class TestCastingDemo 
{

	public static void main(String[] args)
	{
		
		Emp e1=null;
		e1=new Emp(2314,"Kritika Thapliyal",10000.0F);
		WageEmp e2=new WageEmp(222,"Saavi Grover",2000.0F,4,500);
		SalesMan e3= new SalesMan(333,"Tripti",3000.0F,5,300,300000,0.5F);
		Emp e4=new WageEmp(444,"Abhi",4000.0F,2,200);
		Emp e5=new SalesMan(555,"Nitin",5000.0F,4,400,3,300000);
		WageEmp e6=new SalesMan(666,"Tej",5000.0F,1,300,5,500000);
		e2=(WageEmp)e4;
		System.out.println(e2.calcEmpAnnualSal());
		//e2=(WageEmp)e1;
		//System.out.println(e2.calcEmpAnnualSal());
		if( e1 instanceof Emp)
		{
			System.out.println(" Yes e1 is Emp");
		}
		else
		{
			System.out.println(" No e1 is not Emp");
		}
		if( e1 instanceof SalesMan)
		{
			System.out.println(" Yes e1 is SalesMan");
		}
		else
		{
			System.out.println(" No e1 is not SalesMan");
		}
			
	}

}

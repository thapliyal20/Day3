
public class SalesMan extends WageEmp
{
	int sales;
	float commission;
	public SalesMan() {
		super();
	}
	public SalesMan(int empId, String empName, float empSal, int noOfHrs,
			int ratePerHrs,int sales, float commission) {
		super(empId, empName, empSal, noOfHrs, ratePerHrs);
		this.sales = sales;
		this.commission = commission;
		
	}
	
	public float calcEmpAnnualSal()
	{
		return (super.calcEmpAnnualSal())+(sales*commission);
	}
	
	public String dispInfo()
	{
		return super.dispInfo()+" sales "+sales+" commission" +commission;
	}
	
}


public class TestInheritanceDemo 
{

	public static void main(String[] args)
	{
		
		Emp kritika=new Emp(140400,"Kritika Thapliyal",45000.0F);
		WageEmp saavi=new WageEmp(140321,"Saavi Grover",3500.0F,5,400);
		System.out.println(kritika.dispInfo());
		System.out.println(saavi.dispInfo());
		System.out.println("Annual Salary of Kritika: "+kritika.calcEmpAnnualSal());
		System.out.println("Annual Salary of Saavi: "+saavi.calcEmpAnnualSal());
		
		Emp mauli=new WageEmp(333,"Mauli",6000,6,400);			                 //WageEmp is dynamic type
		System.out.println(mauli.dispInfo());
		System.out.println("Annual Salary of Mauli: "+mauli.calcEmpAnnualSal());		//will call the WageEmp function
		
		SalesMan alisha= new SalesMan(123,"Alisha Anand",2,10,1,1,0.20f);
		System.out.println(alisha.dispInfo());
		System.out.println("Annual Salary of Alisha: "+alisha.calcEmpAnnualSal());		
		
	}

}


public class TestAllEmployeeArrayDemo1 
{

	public static void main(String[] args) 
	{
			int empId;
			String empName;
			float empSal;
			int rate;
			float commission;
			
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter the type of Employee: 1.Employee\n 2.WageEmployee\n 3.SalesMan");
			
			Emp emps[]=new Emp[6];
		
		
		emps[0]=new Emp(111,"Kritika",1000.0F);
		emps[1]=new WageEmp(222,"Vaishali",2000.0F,4,500);
		emps[2]=new SalesMan(333,"Prashant",3000.0F,3,300,600000,0.6F);
		emps[3]=new Emp(444,"Tej",78000.0F);
		emps[4]=new WageEmp(555,"Praseeda",45000.0F,4,400);
		emps[5]=new SalesMan(666,"Himanshu",34000.0F,2,400,400000,.04F);
		
		for(int i=0;i<emps.length;i++)
		{
			System.out.println( i +"  th Emp Info :"+emps[i].dispInfo());
			System.out.println( i +"  Annual Salary :"+emps[i].calcEmpAnnualSal());
		
				if(emps[i] instanceof SalesMan)
				{
					System.out.println( i +"  th SalesMan Info :"+emps[i].dispInfo());
				    System.out.println( i +"  Annual Salary :"+emps[i].calcEmpAnnualSal());
				
				}
				else if(emps[i] instanceof WageEmp)
				{
					System.out.println( i +"  th WageEmp Info :"+emps[i].dispInfo());
				    System.out.println( i +"  Annual Salary :"+emps[i].calcEmpAnnualSal());
				}
			

	}

}
	
	
	
	//It's not completed yet.//
